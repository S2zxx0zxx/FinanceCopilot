// Coverage Engine — calculates data coverage ratio (synced / total accounts).
// CRITICAL: This file was MISSING, causing SafeToSpendEngine to crash at import.
// Without this, /financial-state/home and /ai/chat return 500.

export class CoverageEngine {
    static calculateCoverage(totalAccounts, syncedAccounts) {
        const total = Number(totalAccounts) || 0;
        const synced = Number(syncedAccounts) || 0;
        if (total === 0) return 'no_coverage';
        if (synced === 0) return 'no_coverage';
        if (synced >= total) return 'full';
        return 'partial';
    }

    static calculateCoverageRatio(totalAccounts, syncedAccounts) {
        const total = Number(totalAccounts) || 0;
        const synced = Number(syncedAccounts) || 0;
        if (total === 0) return 0;
        return synced / total;
    }
}

export const COVERAGE_VERSION = 'v1.0.0';
