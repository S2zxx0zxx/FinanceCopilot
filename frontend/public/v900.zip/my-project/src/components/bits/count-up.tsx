"use client";

import { useEffect, useRef, useState } from "react";
import { useInView } from "framer-motion";
import { cn } from "@/lib/utils";

interface CountUpProps {
  value: number;
  format?: "currency" | "plain" | "percent" | "text";
  prefix?: string;
  suffix?: string;
  duration?: number;
  decimals?: number;
  className?: string;
}

export function CountUp({
  value,
  format = "plain",
  prefix,
  suffix,
  duration = 1800,
  decimals,
  className,
}: CountUpProps) {
  const ref = useRef<HTMLSpanElement>(null);
  const inView = useInView(ref, { once: true, margin: "-40px" });
  const [display, setDisplay] = useState(0);

  useEffect(() => {
    if (!inView) return;
    let raf = 0;
    const start = performance.now();
    const tick = (now: number) => {
      const p = Math.min((now - start) / duration, 1);
      const eased = 1 - Math.pow(2, -10 * p);
      setDisplay(value * eased);
      if (p < 1) raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [inView, value, duration]);

  const dec =
    decimals ??
    (format === "percent"
      ? 2
      : format === "currency" && value < 100
      ? 2
      : value % 1 !== 0
      ? value < 10
        ? 2
        : 1
      : 0);

  let text: string;
  if (format === "text") {
    text = String(value);
  } else if (format === "percent") {
    text = `${display.toFixed(dec)}%`;
  } else if (format === "currency") {
    // FIXED: ₹ INR instead of $
    if (value >= 1e9) text = `₹${(value / 1e9).toFixed(1)}B`;
    else if (value >= 1e7) text = `₹${(value / 1e7).toFixed(1)}Cr`;
    else if (value >= 1e5) text = `₹${(value / 1e5).toFixed(1)}L`;
    else if (value >= 1000) text = `₹${Math.round(display).toLocaleString("en-IN")}`;
    else text = `₹${display.toFixed(dec)}`;
  } else {
    // plain
    if (value >= 1000) text = Math.round(display).toLocaleString("en-IN");
    else text = display.toFixed(dec);
  }

  return (
    <span ref={ref} className={cn("tabular-nums", className)}>
      {prefix}
      {text}
      {suffix}
    </span>
  );
}
